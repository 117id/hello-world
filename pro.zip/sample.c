#include<stdio.h>

int main(){
	printf("Hello c World\n");

	return 3;
	// main은 shell이 처리 
	// main 함수가 종료할 때 그 값을 운영체제인 shell에 저장한다.
}

